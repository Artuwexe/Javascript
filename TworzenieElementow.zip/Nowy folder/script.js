const elementName = document.querySelector("#elementName");
const form = document.querySelector("form");
const display = document.querySelector(".display");
const colorName = document.querySelector("#colorName");
const tekst = document.querySelector("#tekscior");
let i = 0;
form.addEventListener("submit", function (evt) {
  evt.preventDefault();
  const element = document.createElement(elementName.value);
  element.innerHTML = tekst.value;
  element.style.color = colorName.value;
  element.style.fontSize = "2rem";
  // element.addEventListener("click", function () {
  // this.remove(); //this oznacza nadrzędny element, czyli formularz
  // });
  element.addEventListener("click", (evt) => {
    evt.currentTarget.remove();
  });
  display.append(element); //podpięcie
});
